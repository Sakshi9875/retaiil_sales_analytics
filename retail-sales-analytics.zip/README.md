# 🛒 Retail Sales Analytics (Data Analyst Portfolio Project)

A complete, **GitHub-ready** project for data analyst freshers. Analyze a 1,500+ row retail sales dataset using **Python (Pandas/Matplotlib)**, **SQL (SQLite)**, and build an **interactive BI dashboard** (Power BI/Tableau).

## 📦 Project Structure
```
retail-sales-analytics/
├─ data/
│  └─ retail_sales_dataset.csv
├─ notebooks/
│  └─ retail_sales_analysis.ipynb
├─ scripts/
│  └─ analysis.py
├─ sql/
│  └─ queries.sql
├─ dashboard/
│  └─ powerbi_instructions.md
├─ assets/
│  ├─ monthly_revenue.png
│  └─ top_products.png
├─ .gitignore
├─ requirements.txt
├─ LICENSE
└─ README.md
```

## 🚀 Quick Start
1. **Clone / Download** this repository.
2. Create a virtual environment and install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. **Run the analysis script**:
   ```bash
   python scripts/analysis.py
   ```
   This will generate charts inside `assets/`.
4. **Open the Jupyter Notebook** for full EDA + SQL demo:
   ```bash
   jupyter notebook notebooks/retail_sales_analysis.ipynb
   ```
5. **(Optional)** Build the Power BI dashboard following `dashboard/powerbi_instructions.md`.

## 🧰 Tech Stack
- **Python**: pandas, matplotlib, sqlite3
- **SQL**: SQLite (in-memory) for demos, can adapt to MySQL/PostgreSQL
- **BI**: Power BI or Tableau (instructions included)

## 📈 Included Visuals
- `assets/monthly_revenue.png`: Monthly revenue trend
- `assets/top_products.png`: Top 10 products by revenue

## 📝 What You'll Learn / Showcase
- Data cleaning & preprocessing
- Exploratory data analysis (EDA)
- Writing and explaining SQL queries
- Insight communication and dashboarding
- Reproducible project structure

## 🧪 Sample KPIs (computed by script)
- Total Revenue
- Total Orders
- Total Unique Customers
- Average Order Value (AOV)

## 🗂️ Dataset
Synthetic retail dataset with columns: `Order_ID, Customer_ID, Order_Date, Product_Category, Product, Quantity, Price, Revenue, Region, Payment_Method`.

## 📜 License
MIT — feel free to use and modify for your portfolio.

---

> Tip: Add screenshots (from `assets/`) to your GitHub README to make the repo visually compelling.