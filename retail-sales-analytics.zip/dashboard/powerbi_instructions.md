# Power BI Dashboard Instructions

1. Open **Power BI Desktop** → **Home** → **Get Data** → **Text/CSV** → choose `data/retail_sales_dataset.csv` → **Load**.
2. Ensure `Order_Date` is set to **Date** type (Model view).
3. Create visuals:
   - **Cards**: Total Revenue, Total Orders, Unique Customers, Average Order Value
   - **Line chart**: `Order_Date` (Month) vs `Revenue`
   - **Bar chart**: Top 10 `Product` by `Revenue`
   - **Donut/Pie**: `Payment_Method` by count of `Order_ID`
   - **Stacked bar**: `Region` vs `Revenue`
4. Add slicers for `Year`, `Region`, and `Product_Category`.
5. Add page title **Retail Sales Performance Dashboard** and arrange visuals neatly.