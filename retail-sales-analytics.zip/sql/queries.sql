-- Top 10 customers by revenue
SELECT Customer_ID, SUM(Revenue) AS Total_Revenue
FROM sales
GROUP BY Customer_ID
ORDER BY Total_Revenue DESC
LIMIT 10;

-- Monthly revenue trend
SELECT strftime('%Y-%m', Order_Date) AS YearMonth, SUM(Revenue) AS Revenue
FROM sales
GROUP BY YearMonth
ORDER BY YearMonth;

-- Revenue by region and category
SELECT Region, Product_Category, SUM(Revenue) AS Revenue
FROM sales
GROUP BY Region, Product_Category
ORDER BY Revenue DESC;

-- Average order value
SELECT AVG(Revenue) AS Average_Order_Value
FROM sales;

-- Payment method distribution
SELECT Payment_Method, COUNT(*) AS Orders
FROM sales
GROUP BY Payment_Method
ORDER BY Orders DESC;