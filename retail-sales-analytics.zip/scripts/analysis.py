import pandas as pd
import matplotlib.pyplot as plt
import sqlite3
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "retail_sales_dataset.csv"
ASSETS_PATH = Path(__file__).resolve().parents[1] / "assets"
ASSETS_PATH.mkdir(parents=True, exist_ok=True)

# Load
df = pd.read_csv(DATA_PATH, parse_dates=["Order_Date"])

# KPIs
total_revenue = df["Revenue"].sum()
total_orders = len(df)
unique_customers = df["Customer_ID"].nunique()
aov = df["Revenue"].mean()

print(f"Total Revenue: {total_revenue:,.2f}")
print(f"Total Orders: {total_orders}")
print(f"Unique Customers: {unique_customers}")
print(f"Average Order Value: {aov:,.2f}")

# Charts (one plot per figure, default colors)
# Monthly Revenue Trend
monthly = df.set_index("Order_Date").resample("M")["Revenue"].sum()
plt.figure()
monthly.plot()
plt.title("Monthly Revenue Trend")
plt.xlabel("Month")
plt.ylabel("Revenue")
plt.tight_layout()
plt.savefig(ASSETS_PATH / "monthly_revenue.png", dpi=150)
plt.close()

# Top 10 Products by Revenue
top_products = df.groupby("Product")["Revenue"].sum().sort_values(ascending=False).head(10)
plt.figure()
top_products.plot(kind="barh")
plt.title("Top 10 Products by Revenue")
plt.xlabel("Revenue")
plt.ylabel("Product")
plt.tight_layout()
plt.savefig(ASSETS_PATH / "top_products.png", dpi=150)
plt.close()

# Optional: SQL demo (in-memory)
conn = sqlite3.connect(":memory:")
df.to_sql("sales", conn, index=False, if_exists="replace")
query = "SELECT Customer_ID, SUM(Revenue) AS Total_Revenue FROM sales GROUP BY Customer_ID ORDER BY Total_Revenue DESC LIMIT 5;"
print("\nTop 5 Customers by Revenue (via SQL):")
print(pd.read_sql(query, conn))
conn.close()